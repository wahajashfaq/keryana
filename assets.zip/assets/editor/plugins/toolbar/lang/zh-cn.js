﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'zh-cn', {
	toolbarCollapse: '折叠工具栏',
	toolbarExpand: '展开工具栏',
	toolbarGroups: {
		document: '文档',
		clipboard: '剪贴板/撤销',
		editing: '编辑',
		forms: '表单',
		basicstyles: '基本格式',
		paragraph: '段落',
		links: '链接',
		insert: '插入',
		styles: '样式',
		colors: '颜色',
		tools: '工具'
	},
	toolbars: '工具栏'
} );
