﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'km', {
	bulletedlist: 'បញ្ចូល / លុប​បញ្ជី​ជា​ចំណុច​មូល',
	numberedlist: 'បញ្ចូល / លុប​បញ្ជី​ជា​លេខ'
} );
