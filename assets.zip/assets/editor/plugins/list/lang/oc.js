﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'oc', {
	bulletedlist: 'Inserir/Suprimir una lista amb de piuses',
	numberedlist: 'Inserir/Suprimir una lista numerotada'
} );
