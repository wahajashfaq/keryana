﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'zh', {
	bulletedlist: '插入/移除項目符號清單',
	numberedlist: '插入/移除編號清單清單'
} );
