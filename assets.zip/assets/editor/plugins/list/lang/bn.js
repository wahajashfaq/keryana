﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'bn', {
	bulletedlist: 'বুলেটেড তালিকা প্রবেশ/অপসারন করি',
	numberedlist: 'সাংখ্যিক লিস্টের লেবেল'
} );
